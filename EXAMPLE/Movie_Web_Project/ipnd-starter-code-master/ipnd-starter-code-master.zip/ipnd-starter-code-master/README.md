# DEPRECATED Intro to Programming Nanodegree Starter Code

The files in this repository are here to help you follow along as you complete the Intro to Programming Nanodegree.
Each file contains a short description of what you can expect to learn in the lesson along with a bit of code.
We encourage you to open these files alongside your browser, and add to them as you complete lessons.
To download the starter code, click the Download Zip button, up  and to the right.
